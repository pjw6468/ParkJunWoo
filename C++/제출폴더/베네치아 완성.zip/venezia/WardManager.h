#pragma once
#include "Mecro.h"
#include "MapDraw.h";
#include "Ward.h"

class WardManager
{
private:
	MapDraw m_DrawManager;
protected:
	Ward* WardList;
	string* Story;
	string* m_Ward;
	int Line; //�� ��� ���°�
	int WardCount; //�ܾ� ����
public:
	void WardSet();
	void WardLoad();
	void StoryLoad();
	void StoryShow();
	void WardReset();
	int ItemClear(int WardNum);
	WardManager();
	~WardManager();
};

