#include "Rank.h"



Rank::Rank()
{
}
void Rank::RankSave(string Name, int Stage, int Score)
{
	ofstream Save;
	Save.open("Rank.txt",ios::app);
	if (Save.is_open())
	{
		Save << Name << " " << Stage << " " << Score << endl;
	}
}
void Rank::RankLoad()
{
	RankMemberCount = 0;
	ifstream Load;
	string Name;
	int Score;
	int Stage;
	int i = 0;
	Load.open("Rank.txt");
	while (!Load.eof())
	{
		Load >> Name;
		Load >> Stage;
		Load >> Score;
		RankMemberCount++;
	}
	Load.close();
	RankList = new lank[RankMemberCount];
	Load.open("Rank.txt");
	while (!Load.eof())
	{
		Load >> RankList[i].Name;
		Load >> RankList[i].Stage;
		Load >> RankList[i].Score;
		i++;
	}
	RankAscending();
}
void Rank::RankAscending()
{
	lank tmp;
	for (int i = 0; i < RankMemberCount - 1; i++)
	{
		for (int j = i + 1; j < RankMemberCount; j++)
		{
			if (RankList[i].Score < RankList[j].Score)
			{
				tmp = RankList[i];
				RankList[i] = RankList[j];
				RankList[j] = tmp;
			}
		}
	}
}
void Rank::RankShow()
{
	if (RankMemberCount < 9)
	{
		for (int i = 0; i < RankMemberCount - 1; i++)
		{
			gootoxy(40, 11 + i * 2);
			cout << RankList[i].Name;
			gootoxy(70, 11 + i * 2);
			cout << RankList[i].Stage;
			gootoxy(100, 11 + i * 2);
			cout << RankList[i].Score;
		}
	}
	else
	{
		for (int i = 0; i < 9; i++)
		{
			gootoxy(40, 11 + i * 2);
			cout << RankList[i].Name;
			gootoxy(70, 11 + i * 2);
			cout << RankList[i].Stage;
			gootoxy(100, 11 + i * 2);
			cout << RankList[i].Score;
		}
	}
	getch();
}
Rank::~Rank()
{
}
