#include "Interface.h"

//���� 140 ���� 40

Interface::Interface()
{
}
void Interface::RankMenu()
{
	BoxErase(70, 29);
	BoxDraw(75, 3, 15, 3);
	DrawMidText("RANKING", 75, 4);
	DrawLine(7, 140);
	gotoxy(40, 9);
	cout << "Name";
	gotoxy(70, 9);
	cout << "Stage";
	gotoxy(100, 9);
	cout << "Score";
}
int Interface::MainMenu()
{
	BoxDraw(0,0,70,30);
	BLUE
	DrawMidText("�� �� �� �� ġ �� �� ��",70, 5);
	DrawMidText("1. Game Start", 70, 13);
	DrawMidText("2. Rank", 70, 16);
	DrawMidText("3. Exit", 70, 19);
		return MenuSelectCursor(3, 3, 30, 13);
}
void Interface::StatusMenu(int Life, int Score, string Name)
{
	RED
		gotoxy(3, 35);
	cout << "Life : " << Life;
	gotoxy(60, 35);
	cout << "Score : " << Score;
	gotoxy(110, 35);
	cout << "Name : " << Name;
	ORIGINAL
}
void Interface::StageMenu(int Stage)
{
	BoxErase(70, 29);
	gotoxy(65, 15);
	cout << Stage << " S t a g e";
	Sleep(2000);
	BoxErase(70, 29);
}
Interface::~Interface()
{
}
