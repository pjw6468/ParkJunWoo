#pragma once
#include "MapDraw.h"
class Interface : public MapDraw
{
private:
protected:
public:
	int MainMenu();
	void RankMenu();
	void StatusMenu(int Life, int Score, string Name);
	void StageMenu(int Stage);
	Interface();
	~Interface();
};

