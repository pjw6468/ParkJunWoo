#pragma once
#include "Mecro.h"
class Ward
{
private:
protected:
public:
	string Name;
	int x, y, ItemCode;
	bool ItemStatus;
	bool Status;
	void WardDraw(bool BlindStatus);
	int WardDrop();
	bool Live();
	bool Die(string Name);
	Ward();
	~Ward();
	inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
};

