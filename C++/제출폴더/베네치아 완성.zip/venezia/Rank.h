#pragma once
#include "Mecro.h"
struct lank
{
	string Name;
	int Stage;
	int Score;
};
class Rank
{
private:
	lank* RankList;
	int RankMemberCount;
protected:
public:
	void RankSave(string Name,int Stage,int Score);
	void RankLoad();
	void RankAscending();
	void RankShow();
	inline void gootoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	Rank();
	~Rank();
};

