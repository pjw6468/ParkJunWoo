#include "Ward.h"



Ward::Ward()
{
}
void Ward::WardDraw(bool BlindStatus)
{
	if (BlindStatus == false)
	{
		if (y != 28)
		{
			if (ItemCode == 0)
			{
				gotoxy(x, y);
					cout << Name;
			}
			else
			{
				PLUM
					gotoxy(x, y);
					cout << Name;
					ORIGINAL
			}
		}
		else
		{
			gotoxy(x, y);
			for (int i = 0; i < Name.length(); i++)
				cout << " ";
		}
	}
	else
	{
		if (y != 28)
		{
			for (int i = 0; i < Name.length(); i++)
			{

				if (ItemCode == 0)
				{
					gotoxy(x + i, y);
					cout << "=";
				}
				else
				{
					PLUM
						gotoxy(x + i, y);
					cout << "=";
					ORIGINAL
				}
			}
		}
		else
		{
			gotoxy(x, y);
			for (int i = 0; i < Name.length(); i++)
				cout << " ";
		}
	}
}
int Ward::WardDrop()
{
	if (y != 28)
	{
		gotoxy(x, y);
		for (int i = 0; i < Name.length(); i++)
			cout << " ";
		y += 1;
		return 0;
	}
	else
	{
		return 1;
	}
}
bool Ward::Die(string CheckName)
{
	if (Name == CheckName)
	{
		Status = false;
		for (int i = 0; i < Name.length(); i++)
		{
			gotoxy(x+i, y);
			cout << " ";
		}
		y = 1;
		return true;
	}
	return false;
}
Ward::~Ward()
{
}
