#include "Play.h"



Play::Play()
{
	StoryLoad();
	WardLoad();
	m_sName = "???";
	m_iScore = 0;
	m_iStage = 1;
	m_iKeyCount = 0;
	m_iLife = 5;
	m_bSpeedUpFlag = false;
	m_bSpeedDownFlag = false;
	m_bStopFlag = false;
	m_bBlindFlag = false;
}
void Play::Playing()
{
StatusMenu(m_iLife, m_iScore, m_sName);
	while (1)
	{ 
		switch (MainMenu())
		{
		case 1:
			StoryShow();
			NameSet();
			InGame();
			break;
		case 2:
			RankMenu();
			RankLoad();
			RankShow();
			break;
		case 3:
			return;
		}
	}
}
void Play::NameSet()
{
	BoxDraw(70, 20, 20, 5);
	gotoxy(60, 22);
	cout << "�̸� �Է� : ";
	cin >> m_sName;
}
void Play::InGame()
{
	bool Flag = true;
	bool LevelUp = false;
	while (Flag)
	{
		LevelUp = GameLevel(m_iStage);
		if (LevelUp == true) { m_iStage++; m_bGameFlag = true; }
		else { Flag = false; RankSave(m_sName, m_iStage, m_iScore); Reset(); }
	}
}
bool Play::GameLevel(int Level)
{
	WardSet();
	StageMenu(m_iStage);
	StatusMenu(m_iLife, m_iScore, m_sName);
	char ch;
	int Rnum;
	int Array[30]; //�ߺ��� �ܾ� ���������ʵ��� üũ�� �迭
	int ArrayCount = 0; //üũ�� �迭 ����
	bool DieFlag = false;
	bool FailFlag = false; //���� üũ��
	string Check; //���������� üũ��
	m_iDropSpeed = 750;
	m_bGameFlag = true;
	m_iOldCreateClock = clock();
	m_iOldDropClock = clock();
	while (m_bGameFlag)
	{
		m_iCurClock = clock();
		m_iCurCreateClock = clock();
		m_iCurDropClock = clock();
		m_iCurFailClock = clock();
		if (FailFlag == true && m_iCurFailClock - m_iOldFailClock >= 5000)
		{
			FailFlag = false;
			for (int i = 0; i < m_iKeyCount; i++) { Key[i] = NULL; }
			for (int x = 50; x < 70; x++) { gotoxy(x, 30); cout << " "; }
			m_iKeyCount = 0;
		}
		if (m_iCurCreateClock - m_iOldCreateClock >= 2000 && m_bBlindFlag == false)
		{
			Rnum = rand() % 30;
			for (int i = 0; i < ArrayCount; i++) //�ߺ��� �ܾ �ȳ������� üũ
			{
				if (Rnum == Array[i])
				{
					Rnum = rand() % 30;
					i = 0;
				}
				else if (ArrayCount == 30)
				{
					break;
				}
			}
			if (WardList[Rnum].Status == false)
			{
				Array[ArrayCount] = Rnum;
				WardList[Rnum].Status = true;
				WardList[Rnum].x = rand() % 120 + 3;
				m_iOldCreateClock = m_iCurCreateClock;
			}
		}
		if (m_iCurDropClock - m_iOldDropClock >= m_iDropSpeed)
		{
			for (int i = 0; i < 30; i++)
			{
				if (WardList[i].Status == true)
				{
					m_iLife -= WardList[i].WardDrop();			
					WardList[i].WardDraw(m_bBlindFlag);
					StatusMenu(m_iLife, m_iScore, m_sName);
				}
			}
			m_iOldDropClock = m_iCurDropClock;
		}
		gotoxy(60 + m_iKeyCount, 30);
		if (kbhit())
		{
			if (FailFlag != true) // �ܾ� ���߱� �����ؼ� ����� �ʾ�����
			{
				ch = getche();
				if (ch >= 'a' && ch <= 'z') //�׳� Ÿ��������
				{
					gotoxy(60 + m_iKeyCount, 30);
					Key[m_iKeyCount] = ch;
					Key[m_iKeyCount + 1] = NULL;
					m_iKeyCount++;
				}
				else if (ch == 13) //���� ������
				{
					Check = Key;
					InputDelete(60 + m_iKeyCount, 30);
					for (int i = 0; i < m_iKeyCount; i++) { Key[i] = NULL; }
					m_iKeyCount = 0;
					for (int i = 0; i < 30; i++)
					{
						DieFlag = WardList[i].Die(Check);
						if (i == 29 && DieFlag == false) { FailFlag = true;	m_iOldFailClock = clock(); RED gotoxy(65, 30); cout << "ERROR";ORIGINAL }
						else if (DieFlag == true)
						{
							if (WardList[i].ItemStatus == true) 
							{
								switch (WardList[i].ItemCode)
								{
								case ITEM_SPEED_UP:
									m_bSpeedUpFlag = true;
									m_iDropSpeed = 450;
									m_iOldSpeedUpClock = clock();
									break;
								case ITEM_SPEED_DOWN:
									m_bSpeedDownFlag = true;
									m_iDropSpeed = 1500;
									m_iOldSpeedDownClock = clock();
									break;
								case ITEM_STOP:
									m_bStopFlag = true;
									m_iDropSpeed = 999999;
									m_iOldStopClock = clock();
									break;
								case ITEM_CLEAR:
									BoxErase(70, 29);
									for (int j = 0; j < 30; j++)
									{
										m_iScore += ItemClear(j);
									}
									break;
								case ITEM_BLIND:
									m_bBlindFlag = true;
									m_iOldBlindClock = clock();
									break;
								}
							}
							DieFlag = false;
							m_iScore++;
							StatusMenu(m_iLife, m_iScore, m_sName);
							break;
						}
					}
				}
				else if (ch == 8) //�齺���̽�
				{
					if (m_iKeyCount != 0)
					{
						m_iKeyCount--;
						Key[m_iKeyCount] = NULL;
						gotoxy(60 + m_iKeyCount, 30);
						cout << " ";
					}
				}
			}
		}
		WinDieCheck();
		ItemCheck();
	}
	if (m_iScore >= 5 + m_iStage * 5)
	{
		return true;
	}
	if (m_iLife <= 0)
	{
		return false;
	}

}
void Play::ItemCheck()
{
	if (m_bSpeedUpFlag == true)
	{
		if (m_iCurClock - m_iOldSpeedUpClock >= 5000) { m_bSpeedUpFlag = false; m_iDropSpeed = 750; }
	}
	else if (m_bSpeedDownFlag == true)
	{
		if (m_iCurClock - m_iOldSpeedDownClock >= 5000)	{m_bSpeedDownFlag = false; m_iDropSpeed = 750;	}
	}
	else if (m_bStopFlag == true)
	{
		if (m_iCurClock - m_iOldStopClock >= 5000) { m_bStopFlag = false;  m_iDropSpeed = 750; }
	}
	else if (m_bBlindFlag == true)
	{
		if (m_iCurClock - m_iOldBlindClock >= 3000)
			m_bBlindFlag = false;
	}
}
void Play::WinDieCheck()
{
	if (m_iScore >= 5+m_iStage*5)
	{
		m_bGameFlag = false;
	}
	if (m_iLife <= 0)
	{
		m_bGameFlag = false;
	}
}
void Play::Reset()
{
	m_sName = "???";
	m_iScore = 0;
	m_iStage = 1;
	m_iKeyCount = 0;
	m_iLife = 5;
	m_bGameFlag = true;
	m_bSpeedUpFlag = false;
	m_bSpeedDownFlag = false;
	m_bStopFlag = false;
	m_bBlindFlag = false;
	WardReset();
	StatusMenu(m_iLife, m_iScore, m_sName);
}
Play::~Play()
{
}
