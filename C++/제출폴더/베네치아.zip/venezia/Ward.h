#pragma once
#include "Mecro.h"
class Ward
{
private:
protected:
public:
	string Name;
	int x, y;
	void WardDraw();
	void WardDrop();
	void Live();
	void Die();
	Ward();
	~Ward();
};

