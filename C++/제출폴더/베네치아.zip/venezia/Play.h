#pragma once
#include "Mecro.h"
#include "Interface.h"
#include "WardManager.h"
#include "Ward.h"
class Play :public Interface,WardManager
{
private:
	int m_iScore;
	int m_iLife;
	string m_sName;
protected:
public:
	void Playing();
	Play();
	~Play();
};

