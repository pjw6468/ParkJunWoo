#pragma once
class Rank
{
public:
	Rank();
	~Rank();
};

