#include "Play.h"
int main()
{
	srand(time(NULL));
	system("mode con cols=140 lines=40");
	Play P;
	P.Playing();
	return 0;
}