#include "Interface.h"

//���� 130 ���� 40

Interface::Interface()
{
}
int Interface::MainMenu(int Life,int Score,string Name)
{
	BoxDraw(0,0,70,30);
	BLUE
	DrawMidText("�� �� �� �� ġ �� �� ��",70, 5);
	DrawMidText("1. Game Start", 70, 13);
	DrawMidText("2. Rank", 70, 16);
	DrawMidText("3. Exit", 70, 19);
	RED
	gotoxy(3, 35);
	cout << "Life : ";
	for (int i = 0; i < Life; i++)
		cout << "��";
	gotoxy(60, 35);
	cout << "Score : " << Score;
	gotoxy(110, 35);
	cout << "Name : " << Name;
	ORIGINAL
		return MenuSelectCursor(3, 3, 30, 13);
}
Interface::~Interface()
{
}
