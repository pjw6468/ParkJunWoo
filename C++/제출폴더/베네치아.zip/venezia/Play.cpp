#include "Play.h"



Play::Play()
{
	StoryLoad();
	WardLoad();
	m_sName = "???";
	m_iScore = 0;
	m_iLife = 5;
}
void Play::Playing()
{
	while (1)
	{
		switch (MainMenu(m_iLife, m_iScore, m_sName))
		{
		case 1:
			StoryShow();
			break;
		case 2:
			break;
		case 3:
			return;
		}
	}
}

Play::~Play()
{
}
