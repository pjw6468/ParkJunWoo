#include "Ward.h"



Ward::Ward()
{
}

Ward::~Ward()
{
}
