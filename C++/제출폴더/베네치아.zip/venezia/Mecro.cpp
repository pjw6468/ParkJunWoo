#include "Mecro.h"



Mecro::Mecro()
{
}


Mecro::~Mecro()
{
}
