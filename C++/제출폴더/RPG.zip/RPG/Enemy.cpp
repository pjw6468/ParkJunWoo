#include "Enemy.h"



Enemy::Enemy()
{
}
void Enemy::EnemyListLoad()
{
	ifstream Load;
	Load.open("DefaultMonster.txt");
	Load >> m_iMonsterCount;
	MonsterList = new Monster[m_iMonsterCount];
	for (int i = 0; i < m_iMonsterCount; i++)
	{
		Load >> MonsterList[i].Name;
		Load >> MonsterList[i].Atk;
		Load >> MonsterList[i].MaxHp;
		Load >> MonsterList[i].GetExp;
		Load >> MonsterList[i].Gold;
		MonsterList[i].CurrentHp = MonsterList[i].MaxHp;
	}
}
void Enemy::EnemyListView()
{
	m_DrawManager.BoxErase(30, 35);
	for (int i = 0; i < m_iMonsterCount; i++)
	{
		string buf = "=======";
		buf += MonsterList[i].Name;
		buf += "=======";
		m_DrawManager.DrawMidText(buf, 30, 4+(i*4));
		buf = "���ݷ� = ";
		buf += to_string(MonsterList[i].Atk);
		buf += "\t������ = ";
		buf += to_string(MonsterList[i].CurrentHp);
		buf += "/";
		buf += to_string(MonsterList[i].MaxHp);
		m_DrawManager.DrawMidText(buf, 30, 5+(i*4));
		buf += "\t";
		buf += "GetEXP = ";
		buf += to_string(MonsterList[i].GetExp);
		buf = "\tGold = ";
		buf += to_string(MonsterList[i].Gold);
		m_DrawManager.DrawMidText(buf, 30, 6+(i*4));

	}
	while (getchar() != '\n');
	getch();
}
Enemy::~Enemy()
{
}
