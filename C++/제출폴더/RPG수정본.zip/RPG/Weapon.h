#pragma once
#include "Mecro.h"
#include "MapDraw.h"
#include "Player.h"
struct Mugi {
	string Name;
	int Atk;
	int Price;
};

class Weapon
{
private:
	MapDraw DrawManager;
	bool ShopFlag;
protected:
	int BowCount;
	int GunCount;
	int SwordCount;
	int HammerCount;
	int WandCount;
	int DaggerCount;
	int ReturnGold;
	int EquipWeaponType;
	int EquipWeaponNumber;
	int EquipWeaponAtk;
	string EquipWeaponName;
	Mugi* BowList;
	Mugi* GunList;
	Mugi* SwordList;
	Mugi* HammerList;
	Mugi* WandList;
	Mugi* DaggerList;
public:
	void WeaponLoad();
	void WeaponShop(int Gold);
	void BuyMenu(int WeaponType,int Gold);
	void Buy(int WeaponType, int WeaponNum,int Gold);
	inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	Weapon();
	~Weapon();
};	