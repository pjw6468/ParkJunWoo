#include "Monster.h"
#include "Mecro.h"



Monster::Monster()
{
}


Monster::~Monster()
{
}
