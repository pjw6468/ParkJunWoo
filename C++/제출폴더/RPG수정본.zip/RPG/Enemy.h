#pragma once
#include "Mecro.h"
#include "MapDraw.h"
struct Monster
{
	string Name;
	int Atk;
	int CurrentHp;
	int MaxHp;
	int GetExp;
	int Gold;
};
class Enemy
{
private:
	MapDraw m_DrawManager;
protected:
	Monster* MonsterList;
	int m_iMonsterCount;
public:
	void EnemyListLoad();
	void EnemyListView();
	Enemy();
	~Enemy();
};

