#include "Weapon.h"



Weapon::Weapon()
{
	 BowCount = 0;
	 GunCount = 0;
	 SwordCount = 0;
	 HammerCount = 0;
	 WandCount = 0;
	 DaggerCount = 0;
}
void Weapon::WeaponLoad()
{
	ifstream load;
	string WeaponType;
	int BowSaveCount= 0;
	int GunSaveCount= 0;
	int SwordSaveCount= 0;
	int HammerSaveCount= 0;
	int WandSaveCount= 0;
	int DaggerSaveCount= 0;
	string Name;
	int Num1;
	int Num2;
	load.open("WeaponList.txt");
	while (!load.eof())
	{
		load >> WeaponType;
		if (WeaponType == "Bow") {
			BowCount++;
		}
		if (WeaponType == "Gun") {
			GunCount++;
		}
		if (WeaponType == "Sword") {
			SwordCount++;
		}
		if (WeaponType == "Hammer") {
			HammerCount++;
		}
		if (WeaponType == "Wand") {
				WandCount++;
		}
		if (WeaponType == "Dagger") {
			DaggerCount++;
		}
		load >> Name;
		load >> Num1;
		load >> Num2;
	}
	load.close();
	BowList = new Mugi[BowCount];
	GunList = new Mugi[GunCount];
	SwordList = new Mugi[SwordCount];
	HammerList = new Mugi[HammerCount];
	WandList = new Mugi[WandCount];
	DaggerList = new Mugi[DaggerCount];
	load.open("WeaponList.txt");
	while (!load.eof()){
		load >> WeaponType;
		if (WeaponType == "Bow") {
			load >> BowList[BowSaveCount].Name;
			load >> BowList[BowSaveCount].Atk;
			load >> BowList[BowSaveCount].Price;
			BowSaveCount++;
		}
		else if (WeaponType == "Gun") {
			load >> GunList[GunSaveCount].Name;
			load >> GunList[GunSaveCount].Atk;
			load >> GunList[GunSaveCount].Price;
			GunSaveCount++;
		}
		else if (WeaponType == "Sword") {
			load >> SwordList[SwordSaveCount].Name;
			load >> SwordList[SwordSaveCount].Atk;
			load >> SwordList[SwordSaveCount].Price;
			SwordSaveCount++;
		}
		else if (WeaponType == "Hammer") {
			load >> HammerList[HammerSaveCount].Name;
			load >> HammerList[HammerSaveCount].Atk;
			load >> HammerList[HammerSaveCount].Price;
			HammerSaveCount++;
		}
		else if (WeaponType == "Wand") {
			load >> WandList[WandSaveCount].Name;
			load >> WandList[WandSaveCount].Atk;
			load >> WandList[WandSaveCount].Price;
			WandSaveCount++;
		}
		else if (WeaponType == "Dagger") {
			load >> DaggerList[DaggerSaveCount].Name;
			load >> DaggerList[DaggerSaveCount].Atk;
			load >> DaggerList[DaggerSaveCount].Price;
			DaggerSaveCount++;
		}
	}
	load.close();
}
void Weapon::WeaponShop(int Gold)
{
	ShopFlag = true;
	ORIGINAL
	DrawManager.BoxErase(30, 35);
	DrawManager.DrawMidText("�� �� S H O P �� ��", 30, 10);
	DrawManager.DrawMidText("Dagger", 30, 13);
	DrawManager.DrawMidText("Gun", 30, 16);
	DrawManager.DrawMidText("Wand", 30, 19);
	DrawManager.DrawMidText("Sword", 30, 22);
	DrawManager.DrawMidText("Bow", 30, 25);
	DrawManager.DrawMidText("Hammer", 30, 28);
	DrawManager.DrawMidText("���ư���", 30, 31);
	BuyMenu(DrawManager.MenuSelectCursor(7, 3, 10, 13), Gold);
}
void Weapon::BuyMenu(int WeaponType,int Gold)
{
	int ReturnValue;
	while (1) {
		if (WeaponType == 7)
			break;
		DrawManager.BoxErase(30, 35);
		string buf = "���� ��� : ";
		buf += to_string(Gold);
		if (WeaponType == WEAPONTYPE_DAGGER) {
			DrawManager.DrawMidText(buf, 30, 5);
			DrawManager.DrawMidText("Dagger Shop", 30, 8);
			YELLOW
				for (int i = 0; i < DaggerCount; i++) {
					buf = "���� : ";
					buf += to_string(DaggerList[i].Price);
					buf += "  ���� Ÿ�� : ��� ";
					DrawManager.DrawMidText(buf, 30, 10 + (i * 3));
					buf = "�����̸� : ";
					buf += DaggerList[i].Name;
					buf += "���ݷ� : ";
					buf += to_string(DaggerList[i].Atk);
					DrawManager.DrawMidText(buf, 30, 10 + ((i * 3) + 1));
					if (i + 1 == DaggerCount) {
						ORIGINAL
							DrawManager.DrawMidText("���ư���", 30, 10 + ((i + 1) * 3));
					}
				}
			ReturnValue = DrawManager.MenuSelectCursor(DaggerCount + 1, 3, 5, 10);
			if (ReturnValue != DaggerCount + 1) {
				Buy(WeaponType, ReturnValue - 1, Gold);
				break;
			}
			else
				break;
		}
		else if (WeaponType == WEAPONTYPE_GUN) {
			if (WeaponType == WEAPONTYPE_GUN) {
				DrawManager.DrawMidText(buf, 30, 5);
				DrawManager.DrawMidText("Gun Shop", 30, 8);
				YELLOW
					for (int i = 0; i < GunCount; i++) {
						buf = "���� : ";
						buf += to_string(GunList[i].Price);
						buf += "  ���� Ÿ�� : �� ";
						DrawManager.DrawMidText(buf, 30, 10 + (i * 3));
						buf = "�����̸� : ";
						buf += GunList[i].Name;
						buf += "���ݷ� : ";
						buf += to_string(GunList[i].Atk);
						DrawManager.DrawMidText(buf, 30, 10 + ((i * 3) + 1));
						if (i + 1 == GunCount) {
							ORIGINAL
								DrawManager.DrawMidText("���ư���", 30, 10 + ((i + 1) * 3));
						}
					}
				ReturnValue = DrawManager.MenuSelectCursor(GunCount + 1, 3, 5, 10);
				if (ReturnValue != GunCount + 1) {
					Buy(WeaponType, ReturnValue - 1, Gold);
					break;
				}
				else
					break;
			}
		}
		else if (WeaponType == WEAPONTYPE_WAND) {
			if (WeaponType == WEAPONTYPE_WAND) {
				DrawManager.DrawMidText(buf, 30, 5);
				DrawManager.DrawMidText("Wand Shop", 30, 8);
				YELLOW
					for (int i = 0; i < WandCount; i++) {
						buf = "���� : ";
						buf += to_string(WandList[i].Price);
						buf += "  ���� Ÿ�� : �ϵ� ";
						DrawManager.DrawMidText(buf, 30, 10 + (i * 3));
						buf = "�����̸� : ";
						buf += WandList[i].Name;
						buf += "���ݷ� : ";
						buf += to_string(WandList[i].Atk);
						DrawManager.DrawMidText(buf, 30, 10 + ((i * 3) + 1));
						if (i + 1 == WandCount) {
							ORIGINAL
								DrawManager.DrawMidText("���ư���", 30, 10 + ((i + 1) * 3));
						}
					}
				ReturnValue = DrawManager.MenuSelectCursor(WandCount + 1, 3, 5, 10);
				if (ReturnValue != WandCount + 1) {
					Buy(WeaponType, ReturnValue - 1, Gold);
					break;
				}
				else
					break;
			}
		}
		else if (WeaponType == WEAPONTYPE_SWORD) {
			if (WeaponType == WEAPONTYPE_SWORD) {
				DrawManager.DrawMidText(buf, 30, 5);
				DrawManager.DrawMidText("Sword Shop", 30, 8);
				YELLOW
					for (int i = 0; i < SwordCount; i++) {
						buf = "���� : ";
						buf += to_string(SwordList[i].Price);
						buf += "  ���� Ÿ�� : �� ";
						DrawManager.DrawMidText(buf, 30, 10 + (i * 3));
						buf = "�����̸� : ";
						buf += SwordList[i].Name;
						buf += "���ݷ� : ";
						buf += to_string(SwordList[i].Atk);
						DrawManager.DrawMidText(buf, 30, 10 + ((i * 3) + 1));
						if (i + 1 == SwordCount) {
							ORIGINAL
								DrawManager.DrawMidText("���ư���", 30, 10 + ((i + 1) * 3));
						}
					}
				ReturnValue = DrawManager.MenuSelectCursor(SwordCount + 1, 3, 5, 10);
				if (ReturnValue != SwordCount + 1) {
					Buy(WeaponType, ReturnValue - 1, Gold);
					break;
				}
				else
					break;
			}
		}
		else if (WeaponType == WEAPONTYPE_BOW) {
			if (WeaponType == WEAPONTYPE_BOW) {
				DrawManager.DrawMidText(buf, 30, 5);
				DrawManager.DrawMidText("Bow Shop", 30, 8);
				YELLOW
					for (int i = 0; i < BowCount; i++) {
						buf = "���� : ";
						buf += to_string(BowList[i].Price);
						buf += "  ���� Ÿ�� : Ȱ ";
						DrawManager.DrawMidText(buf, 30, 10 + (i * 3));
						buf = "�����̸� : ";
						buf += BowList[i].Name;
						buf += "���ݷ� : ";
						buf += to_string(BowList[i].Atk);
						DrawManager.DrawMidText(buf, 30, 10 + ((i * 3) + 1));
						if (i + 1 == BowCount) {
							ORIGINAL
								DrawManager.DrawMidText("���ư���", 30, 10 + ((i + 1) * 3));
						}
					}
				ReturnValue = DrawManager.MenuSelectCursor(BowCount + 1, 3, 5, 10);
				if (ReturnValue != BowCount + 1) {
					Buy(WeaponType, ReturnValue - 1, Gold);
					break;
				}
				else
					break;
			}
		}
		else if (WeaponType == WEAPONTYPE_HAMMER) {
			if (WeaponType == WEAPONTYPE_HAMMER) {
				DrawManager.DrawMidText(buf, 30, 5);
				DrawManager.DrawMidText("Hammer Shop", 30, 8);
				YELLOW
					for (int i = 0; i < HammerCount; i++) {
						buf = "���� : ";
						buf += to_string(HammerList[i].Price);
						buf += "  ���� Ÿ�� : �ظ� ";
						DrawManager.DrawMidText(buf, 30, 10 + (i * 3));
						buf = "�����̸� : ";
						buf += HammerList[i].Name;
						buf += "���ݷ� : ";
						buf += to_string(HammerList[i].Atk);
						DrawManager.DrawMidText(buf, 30, 10 + ((i * 3) + 1));
						if (i + 1 == HammerCount) {
							ORIGINAL
								DrawManager.DrawMidText("���ư���", 30, 10 + ((i + 1) * 3));
						}
					}
				ReturnValue = DrawManager.MenuSelectCursor(HammerCount + 1, 3, 5, 10);
				if (ReturnValue != HammerCount + 1) {
					Buy(WeaponType, ReturnValue - 1, Gold);
					break;
				}
				else
					break;
			}
		}
	}
}
void Weapon::Buy(int WeaponType, int WeaponNum,int Gold)
{
	DrawManager.BoxErase(30, 35);
	if (WeaponType == WEAPONTYPE_DAGGER) {
		if (Gold >= DaggerList[WeaponNum].Price) {
			string buf = DaggerList[WeaponNum].Name;
			buf += "�� �����Ͽ����ϴ�.";
			DrawManager.DrawMidText(buf, 30, 16);
			ReturnGold = Gold -= DaggerList[WeaponNum].Price;
			EquipWeaponType = WeaponType;
			EquipWeaponNumber = WeaponNum;
			EquipWeaponAtk = DaggerList[WeaponNum].Atk;
			EquipWeaponName = DaggerList[WeaponNum].Name;
			WeaponBuy = true;
		}
		else
			DrawManager.DrawMidText("���� �����մϴ�.", 30, 16);
	}	
	else if (WeaponType == WEAPONTYPE_BOW) {
		if (Gold >= BowList[WeaponNum].Price) {
			string buf = BowList[WeaponNum].Name;
			buf += "�� �����Ͽ����ϴ�.";
			DrawManager.DrawMidText(buf, 30, 16);
			ReturnGold = Gold -= BowList[WeaponNum].Price;
			EquipWeaponType = WeaponType;
			EquipWeaponNumber = WeaponNum;
			EquipWeaponAtk = BowList[WeaponNum].Atk;
			EquipWeaponName = BowList[WeaponNum].Name;
			WeaponBuy = true;
		}
		else
			DrawManager.DrawMidText("���� �����մϴ�.", 30, 16);
	}
	else if (WeaponType == WEAPONTYPE_WAND) {
		if (Gold >= WandList[WeaponNum].Price) {
			string buf = WandList[WeaponNum].Name;
			buf += "�� �����Ͽ����ϴ�.";
			DrawManager.DrawMidText(buf, 30, 16);
			ReturnGold = Gold -= WandList[WeaponNum].Price;
			EquipWeaponType = WeaponType;
			EquipWeaponNumber = WeaponNum;
			EquipWeaponAtk = WandList[WeaponNum].Atk;
			EquipWeaponName = WandList[WeaponNum].Name;
			WeaponBuy = true;
		}
		else
		DrawManager.DrawMidText("���� �����մϴ�.", 30, 16);
	}
	else if (WeaponType == WEAPONTYPE_HAMMER) {
		if (Gold >= HammerList[WeaponNum].Price) {
			string buf = HammerList[WeaponNum].Name;
			buf += "�� �����Ͽ����ϴ�.";
			DrawManager.DrawMidText(buf, 30, 16);
			ReturnGold = Gold -= HammerList[WeaponNum].Price;
			EquipWeaponType = WeaponType;
			EquipWeaponNumber = WeaponNum;
			EquipWeaponAtk = HammerList[WeaponNum].Atk;
			EquipWeaponName = HammerList[WeaponNum].Name;
			WeaponBuy = true;
		}
		else
			DrawManager.DrawMidText("���� �����մϴ�.", 30, 16);
	}
	else if (WeaponType == WEAPONTYPE_GUN) {
		if (Gold >= GunList[WeaponNum].Price) {
			string buf = GunList[WeaponNum].Name;
			buf += "�� �����Ͽ����ϴ�.";
			DrawManager.DrawMidText(buf, 30, 16);
			ReturnGold = Gold -= GunList[WeaponNum].Price;
			EquipWeaponType = WeaponType;
			EquipWeaponNumber = WeaponNum;
			EquipWeaponAtk = GunList[WeaponNum].Atk;
			EquipWeaponName = GunList[WeaponNum].Name;
			WeaponBuy = true;
		}
		else
		DrawManager.DrawMidText("���� �����մϴ�.", 30, 16);
	}
	else if (WeaponType == WEAPONTYPE_SWORD) {
		if (Gold >= SwordList[WeaponNum].Price) {
			string buf = SwordList[WeaponNum].Name;
			buf += "�� �����Ͽ����ϴ�.";
			DrawManager.DrawMidText(buf, 30, 16);
			ReturnGold = Gold -= SwordList[WeaponNum].Price;
			EquipWeaponType = WeaponType;
			EquipWeaponNumber = WeaponNum;
			EquipWeaponAtk = SwordList[WeaponNum].Atk;
			EquipWeaponName = SwordList[WeaponNum].Name;
			WeaponBuy = true;
		}
		else
		DrawManager.DrawMidText("���� �����մϴ�.", 30, 16);
	}
	system("pause");
}
Weapon::~Weapon()
	{
}
