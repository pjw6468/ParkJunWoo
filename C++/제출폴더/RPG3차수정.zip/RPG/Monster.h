#pragma once
#include "Mecro.h"
struct monster
{
	string Name;
	int Atk;
	int CurrentHp;
	int MaxHp;
	int GetExp;
	int Gold;
};
class Monster
{
private:
protected:
	monster* m_Monster_List;
	int m_iMonsterCount;
public:
	Monster();
	~Monster();
};

