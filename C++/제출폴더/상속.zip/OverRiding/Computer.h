#pragma once
#include <iostream>
#include <Windows.h>
#include <string>
using namespace std;

class Computer
{
private:
	string m_strItem;
	string m_strStat;
	string m_strGpu;
	string m_strCpu;
	string m_strRam;
protected:
	void Menu(bool* State);
	void Menu();
	void Statusshow();
	void Notepad();
	void Calculater();
	void Painter();
	void Computeroff();
public:
	Computer();
	~Computer();
};

