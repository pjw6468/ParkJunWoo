#pragma once
#include <iostream>
#include <Windows.h>
#include <string>
#include "Computer.h"
#define MAX 10
using namespace std;
enum Select
{
	SIGN_IN = 1,
	LOG_IN,
	SHUT_DOWN
};
struct User
{
	string Id;
	string Pw;
	string Name;
	string PhoneNum;
	string Mile;
	int Age;
};
class Login : public Computer
{
private:
	int m_iUserCount;
	User m_UserList[MAX];
public:
	void Menu();
	void Work();
	void SignIn();
	void LogIn();
	void UserMenu(int UNum);
	void UserState(int UNum);
	bool IdJudge(string ID);
	bool PwJudge(string PW);
	Login();
	~Login();
};

