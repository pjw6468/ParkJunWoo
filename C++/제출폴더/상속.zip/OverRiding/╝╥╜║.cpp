#include <iostream>
#include "Login.h"
void main()
{
	Login L;
	L.Work();
}