#include "Mecro.h"
#include "Game.h"
void main()
{
	system("mode con cols=60 lines=40");
	Game G;
	G.EnemyListLoad();
	G.WeaponLoad();
	G.SelectMenu();
}