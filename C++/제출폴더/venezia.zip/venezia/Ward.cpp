#include "Ward.h"



Ward::Ward()
{
}
void Ward::WardDraw()
{
	if (y != 29)
	{
		gotoxy(x, y);
		cout << Name;
	}
}
void Ward::WardDrop()
{
	if (y != 29)
	{
		gotoxy(x, y);
		for (int i = 0; i < Name.length(); i++)
			cout << " ";
		y += 1;
	}
}
bool Ward::Die(string CheckName)
{
	if (Name == CheckName)
	{
		Status = false;
		for (int i = 0; i < Name.length(); i++)
		{
			gotoxy(x + i, y);
			cout << " ";
		}
		return true;
	}
	return false;
}
Ward::~Ward()
{
}
