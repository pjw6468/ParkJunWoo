#include "Rank.h"



Rank::Rank()
{
}


Rank::~Rank()
{
}
