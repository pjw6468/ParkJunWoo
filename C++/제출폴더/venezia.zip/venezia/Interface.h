#pragma once
#include "MapDraw.h"
class Interface : public MapDraw
{
private:
protected:
public:
	int MainMenu();
	void StatusMenu(int Life, int Score, string Name);
	Interface();
	~Interface();
};

