#include "WardManager.h"



WardManager::WardManager()
{
	WardList = new Ward[30];
	for (int i = 0; i < 30; i++)
	{
		WardList[i].Status = false;
		WardList[i].ItemStatus = false;
		WardList[i].x = 0;
		WardList[i].y = 1;
		WardList[i].ItemCode = 0;
	}
}
void WardManager::WardSet()
{
	int Rnum;
	int NumCheck[30];
	int CheckCount = 0;
	bool Flag;
	for (int i = 0; i < 30; i++)
	{
		Flag = true;
		Rnum = rand() % WardCount;
		for (int j = 0; j < CheckCount; j++)
		{
			if (NumCheck[j] == Rnum)
			{
				Flag = false;
				i--;
				break;
			}
		}
		if (Flag == true)
		{
			WardList[i].Name = m_Ward[Rnum];
			Rnum = rand() % 100 + 1;
			if (Rnum < 20) //20%Ȯ���� ������ �ܾ�� ����
			{
				WardList[i].ItemStatus = true;
				WardList[i].ItemCode = rand() % 5 + 1; //������ �ڵ� ����
			}
		}
	}
}
void WardManager::StoryLoad()
{
	ifstream load;
	int StoryNum = 0; //���丮 �迭 �����
	load.open("����ġ��_���丮.txt");
	load >> Line;
	Story = new string[Line];
	while (!load.eof())
	{
		getline(load, Story[StoryNum]);
		StoryNum++;
	}
	load.close();
}
void WardManager::StoryShow()
{
	string ForLoad;
	char ch = getch();
	m_DrawManager.BoxErase(70, 29);
	m_DrawManager.BoxDraw(70, 20,20,5);
	m_DrawManager.DrawMidText("Skip : S", 70, 22);
	for (int i = 0; i < Line; i++)
	{
		if (kbhit())
		{
			char ch = getche();
			if (ch == 's' || ch == 'S')
				m_DrawManager.BoxErase(70, 29);
				break;
		}
		if (i < 10)
		{
			ForLoad = Story[i];
			m_DrawManager.DrawMidText(ForLoad, 70, i + 10);
		}
		else
		{
			int LineNum = 10;
			m_DrawManager.LineErase();
			for (int j = i - 9; j < i; j++)
			{
				ForLoad = Story[j];
				m_DrawManager.DrawMidText(ForLoad, 70,LineNum);
				LineNum++;
			}
			ForLoad = Story[i];
			m_DrawManager.DrawMidText(ForLoad, 70, LineNum);
		}
		Sleep(700);
	}
	m_DrawManager.BoxErase(70, 29);
}
void WardManager::WardLoad()
{
	ifstream load;
	int Count = 0;
	load.open("Word.txt");
	load >> WardCount;
	m_Ward = new string[WardCount];
	while (!load.eof())
	{
		load >> m_Ward[Count];
		Count++;
	}
	load.close();
}
WardManager::~WardManager()
{
}
