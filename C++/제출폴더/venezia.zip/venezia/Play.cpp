#include "Play.h"



Play::Play()
{
	StoryLoad();
	WardLoad();
	m_sName = "???";
	m_iScore = 0;
	m_iKeyCount = 0;
	m_iLife = 5;
	m_iLevel = 1;
}
void Play::Playing()
{
StatusMenu(m_iLife, m_iScore, m_sName);
	while (1)
	{
		switch (MainMenu())
		{
		case 1:
			StoryShow();
			InGame();
			break;
		case 2:
			break;
		case 3:
			return;
		}
	}
}
void Play::InGame()
{
	GameLevel(m_iLevel);
}
bool Play::GameLevel(int Level)
{
	WardSet();
	int Rnum;
	int Array[30]; //�ߺ��� �ܾ� ���������ʵ��� üũ�� �迭
	int ArrayCount = 0; //üũ�� �迭 ����
	int DropSpeed = 1500; //�ܾ� �������� �ӵ�
	char ch;
	bool DieFlag = false;
	bool FailFlag = false;
	string Check; //���������� üũ��
	m_bGameFlag = true;
	m_iOldCreateClock = clock();
	m_iOldDropClock = clock();
	while (m_bGameFlag)
	{
		m_iCurCreateClock = clock();
		m_iCurDropClock = clock();
		m_iCurFailClock = clock();
		if (FailFlag == true && m_iCurFailClock - m_iOldFailClock >= 5000)
		{
			FailFlag = false;
			for (int i = 0; i < m_iKeyCount; i++) { Key[i] = NULL; }
			for (int x = 50; x < 70; x++) { gotoxy(x, 30); cout << " "; }
			m_iKeyCount = 0;
		}
		if (m_iCurCreateClock - m_iOldCreateClock >= (6000 - (Level * 1000))) //���� ��� �ܾ� ���� �ð�
		{
			Rnum = rand() % 30;
			for (int i = 0; i < ArrayCount; i++) //�ߺ��� �ܾ �ȳ������� üũ
			{
				if (Rnum == Array[i])
				{
					Rnum = rand() % 30;
					i = 0;
				}
			}
			if (WardList[Rnum].Status == false)
			{
				Array[ArrayCount] = Rnum;
				WardList[Rnum].Status = true;
				WardList[Rnum].x = rand() % 130 + 3;
				m_iOldCreateClock = m_iCurCreateClock;
			}
		}
		if (m_iCurDropClock - m_iOldDropClock >= DropSpeed)
		{
			for (int i = 0; i < 30; i++)
			{
				if (WardList[i].Status == true)
				{
					WardList[i].WardDrop();
					WardList[i].WardDraw();
				}
			}
			m_iOldDropClock = m_iCurDropClock;
		}
		gotoxy(60 + m_iKeyCount, 30);
		if (kbhit())
		{
			if (FailFlag != true)
			{
				ch = getche();
				if (ch >= 'a' && ch <= 'z') //�׳� Ÿ��������
				{
					gotoxy(60 + m_iKeyCount, 30);
					Key[m_iKeyCount] = ch;
					Key[m_iKeyCount + 1] = NULL;
					m_iKeyCount++;
				}
				else if (ch == 13) //���� ������
				{
					Check = Key;
					InputDelete(60 + m_iKeyCount, 30);
					for (int i = 0; i < m_iKeyCount; i++) { Key[i] = NULL; }
					m_iKeyCount = 0;
					for (int i = 0; i < 30; i++)
					{
						DieFlag = WardList[i].Die(Check);
						if (i == 29 && DieFlag == false) { FailFlag = true;	m_iOldFailClock = clock(); RED gotoxy(65, 30); cout << "ERROR";ORIGINAL }
						else if (DieFlag == true)
						{
							DieFlag = false;
							m_iScore++;
							StatusMenu(m_iLife, m_iScore, m_sName);
							break;
						}
					}
				}
				else if (ch == 8) //�齺���̽�
				{
					if (m_iKeyCount != 0)
					{
						m_iKeyCount--;
						Key[m_iKeyCount] = NULL;
						gotoxy(60 + m_iKeyCount, 30);
						cout << " ";
					}
				}
			}
		}
	}
	return true;
}
Play::~Play()
{
}
