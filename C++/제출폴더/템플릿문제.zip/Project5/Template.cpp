#include "Template.h"


//Template::Template()
//{
//}
//
//Template::~Template()
//{
//}
