#pragma once
using namespace std;
template <typename T>
class Template
{
private:
public:
	//Template();
	inline T func(T num1) { num1++; return num1; }
	T func(T num1, T num2)
	{
		T Min;
		if (num1 > num2) { Min = num2; }
		else { return Min = num1; }
		return Min;
	}
	T func(T num1, T num2, T num3) {
		T Max;
		if (num1 > num2 && num1 > num3)
			Max = num1;
		else if (num2 > num1 && num2 > num3)
			Max = num2;
		else if (num3 > num1 && num3 > num2)
			Max = num3;
		return Max;
	}
	//~Template();
};
//T func(T num1, T num2)
//{
//	T Min;
//	if (num1 > num2) { Min = num2; }
//	else { return Min = num1; }
//	return Min;
//}
//T func(T num1, T num2, T num3)
//{
//	T Max;
//	if (num1 > num2 && num1 > num3)
//		Max = num1;
//	else if (num2 > num1 && num2 > num3)
//		Max = num2;
//	else if (num3 > num1 && num3 > num2)
//		Max = num3;
//	return Max;
//}