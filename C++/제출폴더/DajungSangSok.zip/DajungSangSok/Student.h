#pragma once
#include "Person.h"
#include "School.h"

class Student : public Person , public School
{
private:
public:
	void Start();
	Student();
	~Student();
protected: 


};

