#include "Student.h"



Student::Student()
{
}
void Student::Start()
{
	School::Save();
	Person::Save();
	School::print();
	Person::print();
}

Student::~Student()
{
}
