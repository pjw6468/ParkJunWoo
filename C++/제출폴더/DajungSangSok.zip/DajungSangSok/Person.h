#pragma once
#include <iostream>
#include <string>
using namespace std;

class Person
{
public:
	int Age;
	string Gender;
	string Name;
	Person();
	~Person();
protected:
	void Save();
	void print();
private:
};

