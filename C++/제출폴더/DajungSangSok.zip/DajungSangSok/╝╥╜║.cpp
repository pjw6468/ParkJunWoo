#include <Windows.h>
#include "Student.h"
void main()
{
	Student S;
	S.Start();
	system("pause");
}