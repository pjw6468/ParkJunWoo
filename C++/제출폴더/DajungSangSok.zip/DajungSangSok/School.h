#pragma once
#include <iostream>
#include <string>
using namespace std;
class School
{
private:
public:
	int Number;
	int Class;
	int ClassNumber;
	School();
	~School();
protected:
	void Save();
	void print();

};

