#include "Player.h"


Player::Player()
{
}
void Player::PlayerInfoSet() //�⺻����
{
	YELLOW
	m_Me = new Me;
	m_DrawManager.BoxErase(30, 35);
	m_DrawManager.DrawMidText("Player �̸� �Է� : ", 30, 15);
	gotoxy(42, 15);
	cin >> m_Me->Name;
	Load.open("DefaultPlayer.txt");
	Load >> m_Me->Atk;
	Load >> m_Me->MaxHp;
	Load >> m_Me->MaxExp;
	Load >> m_Me->GetExp;
	Load >> m_Me->Level;
	Load >> m_Me->Gold;
	m_Me->CurrentExp = 0;
	m_Me->CurrentHp = m_Me->MaxHp;
	Load.close();
	ORIGINAL
}
void Player::PlayerInfoView() //�÷��̾� ����
{
	YELLOW
		m_DrawManager.BoxErase(30, 35);
	string buf = "=====";
	buf += m_Me->Name;
	buf += "<";
	buf += to_string(m_Me->Level);
	buf += "Lv>=====";
	m_DrawManager.DrawMidText(buf, 30, 15);
	buf = "���ݷ� = ";
	buf += to_string(m_Me->Atk);
	buf += "\t������ = ";
	buf += to_string(m_Me->CurrentHp);
	buf += "/";
	buf += to_string(m_Me->MaxHp);
	m_DrawManager.DrawMidText(buf, 30, 16);
	buf = "����ġ = ";
	buf += to_string(m_Me->CurrentExp);
	buf += "/";
	buf += to_string(m_Me->MaxExp);
	buf += "\t";
	buf += "GetEXP = ";
	buf += to_string(m_Me->GetExp);
	m_DrawManager.DrawMidText(buf, 30, 17);
	buf = "Gold = ";
	buf += to_string(m_Me->Gold);
	m_DrawManager.DrawMidText(buf, 30, 18);
	ORIGINAL
		getch();
}
void Player::PlayerInfoSave(int SlotNum) //���̺�
{
	char buf[256];
	sprintf(buf, "SavePlayer%d.txt",SlotNum);
	Save.open(buf);
	if (Save.is_open())
	{
		Save << m_Me->Name << " ";
		Save << m_Me->Atk << " ";
		Save << m_Me->CurrentHp << " ";
		Save << m_Me->MaxHp << " ";
		Save << m_Me->Level << " ";
		Save << m_Me->GetExp << " ";
		Save << m_Me->CurrentExp << " ";
		Save << m_Me->MaxExp << " ";
		Save << m_Me->Gold;
	}
}
bool Player::PlayerInfoLoad(int SlotNum) //�ε�
{
	char buf[256];
	m_Me = new Me;
	sprintf(buf, "SavePlayer%d.txt", SlotNum);
	if (SlotCheck[SlotNum] == YES)
	{
		Load.open(buf);
		Load >> m_Me->Name;
		Load >> m_Me->Atk;
		Load >> m_Me->CurrentHp;
		Load >> m_Me->MaxHp;
		Load >> m_Me->Level;
		Load >> m_Me->GetExp;
		Load >> m_Me->CurrentExp;
		Load >> m_Me->MaxExp;
		Load >> m_Me->Gold;
		Load.close();
		return true;
	}
	else
	{
		m_DrawManager.BoxErase(30, 35);
		m_DrawManager.DrawMidText("�ش� ���Կ� ������ �����ϴ�.", 35, 15);
		gotoxy(3, 16);
		system("pause");
		return false;
	}
}
Player::~Player()
{
}
