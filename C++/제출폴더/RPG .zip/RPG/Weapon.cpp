#include "Weapon.h"



Weapon::Weapon()
{
}


Weapon::~Weapon()
{
}
