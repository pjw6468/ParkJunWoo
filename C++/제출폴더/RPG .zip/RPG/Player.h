#pragma once
#include "Mecro.h"
#include "MapDraw.h"
struct Me
{
	string Name;
	int Atk;
	int CurrentHp;
	int MaxHp;
	int Level;
	int GetExp;
	int CurrentExp;
	int MaxExp;
	int Gold;
};

class Player
{
private:
	MapDraw m_DrawManager;
protected:
	Me* m_Me;
	ifstream Load;
	ofstream Save;
public:
	Player();
	int SlotCheck[10];
	void PlayerInfoSet();
	void PlayerInfoView();
	void PlayerInfoSave(int i);
	bool PlayerInfoLoad(int i);
	~Player();
	inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
};

