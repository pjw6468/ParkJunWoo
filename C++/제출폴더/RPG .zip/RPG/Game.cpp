#include "Game.h"



Game::Game()
{
	srand((unsigned)time(NULL));
}
void Game::SelectMenu()
{
	while (1)
	{
		MainMenu();
		switch(m_iReturnValue)
		{
		case STARTTYPE_NEWSTART:
			PlayerInfoSet();
			Playing();
			break;
		case STARTTYPE_LOADSTART:
			FileMenu();
			GameStart=PlayerInfoLoad(m_iReturnValue);
			if (GameStart == true)
				Playing();
			break;
		case STARTTYPE_EXIT:
			return;
		}
	}
}
void Game::MainMenu()
{
	system("cls");
	BLUE
	BoxDraw(0,0,30,35);
	RED
	DrawMidText("�١� DunGeonRPG �ڡ�", 30, 10);
	DrawMidText("NEW GAME", 30, 13);
	DrawMidText("Load GAME", 30, 16);
	DrawMidText("Game Exit", 30, 19);
	m_iReturnValue = MenuSelectCursor(3, 3, 10, 13);
}
void Game::FileMenu()
{
	GREEN
		BoxErase(30, 35);
	char buf[256];
	string Slot;
	for (int i = 1; i <= 10; i++)
	{
		sprintf(buf, "SavePlayer%d.txt", i);
		ifstream in(buf);
		Slot += to_string(i);
		Slot += "��° ���� : <���Ͽ��� : ";
		if (in.is_open())
		{
			Slot += "O>";
			SlotCheck[i] = YES;
		}
		else
		{
			Slot += "X>";
			SlotCheck[i] = NO;
		}
		DrawMidText(Slot, 30, 6 + (i * 2));
		Slot = "";
		Save.close();
	}
	DrawMidText("11. ���ư���", 30, 28);
	m_iReturnValue = MenuSelectCursor(11, 2, 5, 8);
	ORIGINAL
}
void Game::Playing()
{
	Flag = true;
	EnemyListLoad();
	while (Flag)
	{
		InGameMenu();
		switch (m_iReturnValue)
		{
		case MENUTYPE_DUNGEON:
			DungeonMenu();
			break;
		case MENUTYPE_PLAYERINFO:
			PlayerInfoView();
			break;
		case MENUTYPE_MONSTERINFO:
			EnemyListView();
			break;
		case MENUTYPE_WEAPONSHOP:
			break;
		case MENUTYPE_SAVE:
			FileMenu();
			PlayerInfoSave(m_iReturnValue);
			break;
		case MENUTYPE_EXIT:
			Flag = false;
			break;
		}
	}
	Flag = true;
}
void Game::InGameMenu()
{
	RED
		BoxErase(30, 35);
	DrawMidText("�١� Menu �ڡ�", 30, 10);
	DrawMidText("Dungeon", 30, 12);
	DrawMidText("Player Info", 30, 14);
	DrawMidText("Monster Info", 30, 16);
	DrawMidText("Weapon Shop", 30, 18);
	DrawMidText("Save", 30, 20);
	DrawMidText("Exit", 30, 22);
	m_iReturnValue = MenuSelectCursor(6, 2, 5, 12);
	ORIGINAL
}
void Game::DungeonMenu()
{
	DFlag = true;
	while (DFlag)
	{
		BLOOD
			BoxErase(30, 35);
		DrawMidText("==== ���� �Ա� ====", 30, 5);
		for (int i = 0; i < m_iMonsterCount; i++)
		{
			string buf = to_string(i + 1);
			buf += "�� ���� : [";
			buf += MonsterList[i].Name;
			buf += "]";
			DrawMidText(buf, 30, 10 + i * 3);
			if (i + 1 == m_iMonsterCount)
				DrawMidText("���ư���", 30, 10 + (i + 1) * 3);
		}
		m_iReturnValue = MenuSelectCursor(7, 3, 5, 10) - 1;
		if (m_iReturnValue != 6)
			Battle();
		else
			DFlag = false;
	}
}
void Game::Battle()
{
	BoxErase(30, 35);
	BFlag = true;
	while (BFlag)
	{
		Attack();
		YELLOW
		string buf = "=====";
		buf += m_Me->Name;
		buf += "<";
		buf += to_string(m_Me->Level);
		buf += "Lv>=====";
		DrawMidText(buf, 30, 3);
		buf = "���ݷ� = ";
		buf += to_string(m_Me->Atk);
		buf += "\t������ = ";
		buf += to_string(m_Me->CurrentHp);
		buf += "/";
		buf += to_string(m_Me->MaxHp);
		DrawMidText(buf, 30, 4);
		buf = "����ġ = ";
		buf += to_string(m_Me->CurrentExp);
		buf += "/";
		buf += to_string(m_Me->MaxExp);
		buf += "\t";
		buf += "GetEXP = ";
		buf += to_string(m_Me->GetExp);
		DrawMidText(buf, 30, 5);
		buf = "Gold = ";
		buf += to_string(m_Me->Gold);
		DrawMidText(buf, 30, 6);
		DrawMidText("���� : 1 ���� : 2 �� : 3", 30, 8);
		RED
			DrawMidText("===========================VS===========================", 30, 17);
		GRAY
		buf = "=======";
		buf += MonsterList[m_iReturnValue].Name;
		buf += "=======";
		DrawMidText(buf, 30,29);
		buf = "���ݷ� = ";
		buf += to_string(MonsterList[m_iReturnValue].Atk);
		buf += "\t������ = ";
		buf += to_string(MonsterList[m_iReturnValue].CurrentHp);
		buf += "/";
		buf += to_string(MonsterList[m_iReturnValue].MaxHp);
		DrawMidText(buf, 30, 30);
		buf = "GetEXP = ";
		buf += to_string(MonsterList[m_iReturnValue].GetExp);
		buf += "\tGold = ";
		buf += to_string(MonsterList[m_iReturnValue].Gold);
		DrawMidText(buf, 30, 31);
	}
}
void Game::Attack()
{
	int Rnum;
	switch (getch())
	{
	case ROCK:
		AttackType = 1;
		break;
	case SCISSORS:
		AttackType = 2;
		break;
	case PAPER:
		AttackType = 3;
		break;
	}
	BoxErase(30, 35);
	Rnum = (rand() % 3) + 1;
	if (AttackType == 1) //��������
	{
		if (Rnum == 1)//��밡 ����
		{
			YELLOW
			DrawMidText("����", 30, 10);
			RED
			DrawMidText("DRAW", 30, 11);
			DrawMidText("DRAW", 30, 19);
			GRAY
			DrawMidText("����", 30, 20);
			ORIGINAL
				BattleCheck = 3;
		}
		else if (Rnum == 2) //��밡 ����
		{
			YELLOW
				DrawMidText("����", 30, 10);
			RED
				DrawMidText("WIN", 30, 11);
			DrawMidText("LOSE", 30, 19);
			GRAY
				DrawMidText("����", 30, 20);
			ORIGINAL
				BattleCheck = 1;
		}
		else if (Rnum == 3) //��밡 ��
		{
			YELLOW
				DrawMidText("����", 30, 10);
			RED
				DrawMidText("LOSE", 30, 11);
			DrawMidText("WIN", 30, 19);
			GRAY
				DrawMidText("��", 30, 20);
			ORIGINAL
				BattleCheck = 2;
		}
	}
	if (AttackType == 2) //��������
	{
		if (Rnum == 1)
		{
			YELLOW
				DrawMidText("����", 30, 10);
			RED
				DrawMidText("LOSE", 30, 11);
			DrawMidText("WIN", 30, 19);
			GRAY
				DrawMidText("����", 30, 20);
			ORIGINAL
				BattleCheck = 2;
		}
		else if (Rnum == 2)
		{
			YELLOW
				DrawMidText("����", 30, 10);
			RED
				DrawMidText("DRAW", 30, 11);
			DrawMidText("DRAW", 30, 19);
			GRAY
				DrawMidText("����", 30, 20);
			ORIGINAL
				BattleCheck = 3;
		}
		else if (Rnum == 3)
		{
			YELLOW
				DrawMidText("����", 30, 10);
			RED
				DrawMidText("WIN", 30, 11);
			DrawMidText("LOSE", 30, 19);
			GRAY
				DrawMidText("��", 30, 20);
			ORIGINAL
				BattleCheck = 1;
		}
	}
	if (AttackType == 3) //������
	{
		if (Rnum == 1)
		{
			YELLOW
				DrawMidText("��", 30, 10);
			RED
				DrawMidText("WIN", 30, 11);
			DrawMidText("LOSE", 30, 19);
			GRAY
				DrawMidText("����", 30, 20);
			ORIGINAL
				BattleCheck = 1;
		}
		else if (Rnum == 2)
		{
			YELLOW
				DrawMidText("��", 30, 10);
			RED
				DrawMidText("LOSE", 30, 11);
			DrawMidText("WIN", 30, 19);
			GRAY
				DrawMidText("����", 30, 20);
			ORIGINAL
				BattleCheck = 2;
		}
		else if (Rnum == 3)
		{
			YELLOW
				DrawMidText("��", 30, 10);
			RED
				DrawMidText("DRAW", 30, 11);
			DrawMidText("DRAW", 30, 19);
			GRAY
				DrawMidText("��", 30, 20);
			ORIGINAL
				BattleCheck = 3;
		}
	}


	if (BattleCheck == 1)
		MonsterList[m_iReturnValue].CurrentHp -= m_Me->Atk;
	else if (BattleCheck == 2)
		m_Me->CurrentHp -= MonsterList[m_iReturnValue].Atk;
	DeathCheck();
}
void Game::DeathCheck()
{
	string buf;
	if (m_Me->CurrentHp <= 0)
	{
		BFlag = false;
		DFlag = false;
		BoxErase(30, 35);
		RED
			DrawMidText("���� ����",30,15);
		Flag = false;
		Reset();
		system("pause");
	}
	if (MonsterList[m_iReturnValue].CurrentHp <= 0)
	{
		Reset();
		BFlag = false;
		DFlag = false;
		MonsterList[m_iReturnValue].CurrentHp = MonsterList[m_iReturnValue].MaxHp;
		m_Me->CurrentExp += MonsterList[m_iReturnValue].GetExp;
		m_Me->Gold += MonsterList[m_iReturnValue].Gold;
		if (m_Me->CurrentExp >= m_Me->MaxExp)
		{
			buf = m_Me->Name;
			buf += "�� ������!";
			BoxErase(30, 35);
			DrawMidText(buf, 30, 15);
			m_Me->CurrentExp = m_Me->CurrentExp - m_Me->MaxExp;
			m_Me->MaxExp += 10;
			m_Me->Level++;
			m_Me->Atk += rand() % 3 + 1;
			m_Me->MaxHp += rand() % 5 + 1;
			m_Me->CurrentHp = m_Me->MaxHp;
			system("pause");
		}
	}

}
void Game::Reset()
{
	AttackType = 0;
	BattleCheck = 0;
}
Game::~Game()
{
	if (m_Me != NULL)
		m_Me == NULL;
	if (m_Me == NULL)
		delete m_Me;
}
