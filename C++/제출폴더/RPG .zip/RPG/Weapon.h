#pragma once
class Weapon
{
public:
	Weapon();
	~Weapon();
};

