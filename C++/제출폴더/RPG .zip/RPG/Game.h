#pragma once
#include "MapDraw.h"
#include "Player.h"
#include "Weapon.h"
#include "Enemy.h"
#include "Mecro.h"
class Game : public MapDraw,public Player,public Weapon,public Enemy
{
private:
	int m_iReturnValue;
	int AttackType;
	int BattleCheck;
	bool GameStart;
	bool Flag = true;
	bool BFlag;
	bool DFlag;
public:
	void MainMenu();
	void SelectMenu();
	void FileMenu();
	void DungeonMenu();
	void InGameMenu();
	void Playing();
	void Battle();
	void Attack();
	void DeathCheck();
	void Reset();
	Game();
	~Game();
};
